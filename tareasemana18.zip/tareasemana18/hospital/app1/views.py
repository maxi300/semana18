from django.shortcuts import render
from .models import Medico, Paciente
from .formularios import add_medic as fm
from django.http import HttpResponseRedirect


def index(request):
    return render(request,"index.html")


def list_med(request):
    medicos= Medico.objects.all()
    return render(request, "lismed.html",{"lismed":medicos})
# Create your views here.



def list_pac(request):
    paciente= Paciente.objects.all()
    return render(request, "lispa.html",{"lispa":paciente})
# Create your views here.



        
def add_pac(request):
    if request.method == "POST":
        formulario = fm.Add_pac(request.POST)
        if formulario.is_valid():
            nuevo_paciente = Paciente(
                nombre=formulario.cleaned_data["nombre"],
                apellido=formulario.cleaned_data["apellido"],
                fecha_nacimiento=formulario.cleaned_data["cumple"],
                sexo=formulario.cleaned_data["sexo"],
                altura=formulario.cleaned_data["altura"],
              
            )
            nuevo_paciente.save()
            return HttpResponseRedirect("/")
    else:
        formulario = fm.Add_pac()
        return render(request, "add_pac.html", {"form": formulario})













        
def add_med(request):
    if request.method == "POST":
        formulario = fm.Add_medic(request.POST)
        if formulario.is_valid():
            nuevo_medico = Medico(
                nombre=formulario.cleaned_data["nombre"],
                apellido=formulario.cleaned_data["apellido"],
                especialidad=formulario.cleaned_data["especialidad"]
            )
            nuevo_medico.save()
            return HttpResponseRedirect("/")
    else:
        formulario = fm.Add_medic()
        return render(request, "Add_medic.html", {"form": formulario})